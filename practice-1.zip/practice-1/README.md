# Practice 1

A Pen created on CodePen.

Original URL: [https://codepen.io/Craiz/pen/gbMaJLP](https://codepen.io/Craiz/pen/gbMaJLP).

